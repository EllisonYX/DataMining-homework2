#-*- coding: utf-8 -*- 
import csv
import pandas as pd
import numpy as np

# get transaction mode
def getTransaction(full_item, bool_item):
    ret = []
    for i in range(len(full_item)):
        if bool_item[i]=='yes':
            ret.append(full_item[i])
    return ret

def preProcess():
    ret = []
    attr = ['a1','a2','a3','a4','a5','a6','d1','d2']
    data = pd.read_csv('diagnosisData.csv')
    a1 = data['a1']
    a1[a1>37.5]='yes'
    a1[a1<=37.5]='no'
    data['a1'] = a1
    print(data)
    for i in range(len(data)):
        trans = getTransaction(attr, data.loc[i])
        ret.append(trans)
        print (trans)
    return ret


