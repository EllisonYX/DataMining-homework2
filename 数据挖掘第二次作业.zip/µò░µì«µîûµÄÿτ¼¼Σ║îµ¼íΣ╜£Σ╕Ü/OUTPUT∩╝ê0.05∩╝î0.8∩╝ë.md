  a1[a1>37.5]='yes'
      a1   a2   a3   a4   a5   a6   d1   d2
0     no   no  yes   no   no   no   no   no
1     no   no   no  yes  yes  yes  yes   no
2     no   no  yes   no   no   no   no   no
3     no   no   no  yes  yes  yes  yes   no
4     no   no  yes   no   no   no   no   no
5     no   no  yes   no   no   no   no   no
6     no   no   no  yes  yes  yes  yes   no
7     no   no  yes   no   no   no   no   no
8     no   no   no  yes  yes  yes  yes   no
9     no   no   no  yes  yes  yes  yes   no
10    no   no   no  yes  yes  yes  yes   no
11    no   no  yes   no   no   no   no   no
12    no   no  yes   no   no   no   no   no
13    no   no   no  yes  yes  yes  yes   no
14    no   no  yes   no   no   no   no   no
15    no   no  yes   no   no   no   no   no
16    no   no   no  yes  yes  yes  yes   no
17    no   no   no  yes  yes  yes  yes   no
18    no   no   no  yes  yes  yes  yes   no
19    no   no  yes   no   no   no   no   no
20    no   no   no  yes  yes   no  yes   no
21    no   no   no  yes  yes   no  yes   no
22    no   no  yes   no   no   no   no   no
23    no   no   no  yes  yes  yes  yes   no
24    no   no   no  yes  yes  yes  yes   no
25    no   no   no  yes  yes  yes  yes   no
26    no   no   no  yes  yes  yes  yes   no
27    no   no   no  yes   no   no  yes   no
28    no   no  yes   no   no   no   no   no
29    no   no   no  yes  yes  yes  yes   no
..   ...  ...  ...  ...  ...  ...  ...  ...
90   yes   no   no   no   no   no   no   no
91   yes  yes  yes   no  yes   no   no  yes
92   yes  yes  yes  yes  yes  yes  yes  yes
93   yes  yes  yes  yes  yes   no  yes  yes
94   yes   no   no   no   no   no   no   no
95   yes  yes  yes   no  yes   no   no  yes
96   yes   no  yes  yes   no  yes   no  yes
97   yes   no  yes  yes   no  yes   no  yes
98   yes  yes  yes  yes  yes   no  yes  yes
99   yes  yes  yes  yes  yes   no  yes  yes
100  yes   no  yes  yes   no  yes   no  yes
101  yes  yes  yes  yes  yes  yes  yes  yes
102  yes   no   no   no   no   no   no   no
103  yes  yes  yes   no  yes   no   no  yes
104  yes   no  yes  yes   no  yes   no  yes
105  yes  yes  yes  yes  yes  yes  yes  yes
106  yes  yes  yes  yes  yes   no  yes  yes
107  yes   no   no   no   no   no   no   no
108  yes  yes  yes   no  yes   no   no  yes
109  yes   no  yes  yes   no  yes   no  yes
110  yes  yes  yes  yes  yes  yes  yes  yes
111  yes   no   no   no   no   no   no   no
112  yes  yes  yes   no  yes   no   no  yes
113  yes   no  yes  yes   no  yes   no  yes
114  yes  yes  yes  yes  yes   no  yes  yes
115  yes   no  yes  yes   no  yes   no  yes
116  yes   no   no   no   no   no   no   no
117  yes  yes  yes   no  yes   no   no  yes
118  yes   no  yes  yes   no  yes   no  yes
119  yes   no  yes  yes   no  yes   no  yes

[120 rows x 8 columns]
['a3']
['a4', 'a5', 'a6', 'd1']
['a3']
['a4', 'a5', 'a6', 'd1']
['a3']
['a3']
['a4', 'a5', 'a6', 'd1']
['a3']
['a4', 'a5', 'a6', 'd1']
['a4', 'a5', 'a6', 'd1']
['a4', 'a5', 'a6', 'd1']
['a3']
['a3']
['a4', 'a5', 'a6', 'd1']
['a3']
['a3']
['a4', 'a5', 'a6', 'd1']
['a4', 'a5', 'a6', 'd1']
['a4', 'a5', 'a6', 'd1']
['a3']
['a4', 'a5', 'd1']
['a4', 'a5', 'd1']
['a3']
['a4', 'a5', 'a6', 'd1']
['a4', 'a5', 'a6', 'd1']
['a4', 'a5', 'a6', 'd1']
['a4', 'a5', 'a6', 'd1']
['a4', 'd1']
['a3']
['a4', 'a5', 'a6', 'd1']
['a4', 'd1']
['a4', 'a5', 'd1']
['a3']
['a4', 'd1']
['a3']
['a4', 'a5', 'a6', 'd1']
['a4', 'd1']
['a3']
['a4', 'd1']
['a4', 'a5', 'd1']
['a3']
['a3']
['a4', 'a5', 'a6', 'd1']
['a4', 'd1']
['a4', 'd1']
['a1', 'a4', 'a5', 'd1']
['a1', 'a4', 'a5', 'd1']
['a1', 'a4', 'a5', 'a6', 'd1']
['a1', 'a4', 'a5', 'd1']
['a1', 'a4', 'a5', 'd1']
['a1', 'a3']
['a1', 'a4', 'd1']
['a1', 'a3']
['a1', 'a4', 'a5', 'a6', 'd1']
['a1', 'a4', 'd1']
['a1', 'a4', 'a5', 'd1']
['a1', 'a4', 'a5', 'd1']
['a1', 'a3']
['a1', 'a4', 'a5', 'a6', 'd1']
['a1', 'a4', 'd1']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'd1', 'd2']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a2', 'a3', 'a4', 'a5', 'd1', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1']
['a1', 'a2', 'a3', 'a5', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
['a1', 'a3', 'a4', 'a6', 'd2']
candidate set:
a1:75
a2:29
a3:70
a4:80
a5:59
a6:50
d1:59
d2:50
after pruning:
a1:75
a2:29
a3:70
a4:80
a5:59
a6:50
d1:59
d2:50
candidate set:
a1,a2:29
a1,a3:53
a1,a4:52
a1,a5:38
a1,a6:33
a1,d1:31
a1,d2:50
a2,a3:29
a2,a4:19
a2,a5:29
a2,a6:9
a2,d1:19
a2,d2:29
a3,a4:40
a3,a5:29
a3,a6:30
a3,d1:19
a3,d2:50
a4,a5:49
a4,a6:50
a4,d1:59
a4,d2:40
a5,a6:29
a5,d1:49
a5,d2:29
a6,d1:29
a6,d2:30
d1,d2:19
after pruning:
a1,a2:29
a1,a3:53
a1,a4:52
a1,a5:38
a1,a6:33
a1,d1:31
a1,d2:50
a2,a3:29
a2,a4:19
a2,a5:29
a2,d1:19
a2,d2:29
a3,a4:40
a3,a5:29
a3,a6:30
a3,d1:19
a3,d2:50
a4,a5:49
a4,a6:50
a4,d1:59
a4,d2:40
a5,a6:29
a5,d1:49
a5,d2:29
a6,d1:29
a6,d2:30
d1,d2:19
candidate set:
a1,a2,a3:29
a1,a2,a4:19
a1,a2,a5:29
a1,a2,d1:19
a1,a2,d2:29
a1,a3,a4:40
a1,a3,a5:29
a1,a3,a6:30
a1,a3,d1:19
a1,a3,d2:50
a1,a4,a5:28
a1,a4,a6:33
a1,a4,d1:31
a1,a4,d2:40
a1,a5,a6:12
a1,a5,d1:28
a1,a5,d2:29
a1,a6,d1:12
a1,a6,d2:30
a1,d1,d2:19
a2,a3,a4:19
a2,a3,a5:29
a2,a3,d1:19
a2,a3,d2:29
a2,a4,a5:19
a2,a4,d1:19
a2,a4,d2:19
a2,a5,d1:19
a2,a5,d2:29
a2,d1,d2:19
a3,a4,a5:19
a3,a4,a6:30
a3,a4,d1:19
a3,a4,d2:40
a3,a5,a6:9
a3,a5,d1:19
a3,a5,d2:29
a3,a6,d1:9
a3,a6,d2:30
a3,d1,d2:19
a4,a5,a6:29
a4,a5,d1:49
a4,a5,d2:19
a4,a6,d1:29
a4,a6,d2:30
a4,d1,d2:19
a5,a6,d1:29
a5,a6,d2:9
a5,d1,d2:19
a6,d1,d2:9
after pruning:
a1,a2,a3:29
a1,a2,a4:19
a1,a2,a5:29
a1,a2,d1:19
a1,a2,d2:29
a1,a3,a4:40
a1,a3,a5:29
a1,a3,a6:30
a1,a3,d1:19
a1,a3,d2:50
a1,a4,a5:28
a1,a4,a6:33
a1,a4,d1:31
a1,a4,d2:40
a1,a5,a6:12
a1,a5,d1:28
a1,a5,d2:29
a1,a6,d1:12
a1,a6,d2:30
a1,d1,d2:19
a2,a3,a4:19
a2,a3,a5:29
a2,a3,d1:19
a2,a3,d2:29
a2,a4,a5:19
a2,a4,d1:19
a2,a4,d2:19
a2,a5,d1:19
a2,a5,d2:29
a2,d1,d2:19
a3,a4,a5:19
a3,a4,a6:30
a3,a4,d1:19
a3,a4,d2:40
a3,a5,d1:19
a3,a5,d2:29
a3,a6,d2:30
a3,d1,d2:19
a4,a5,a6:29
a4,a5,d1:49
a4,a5,d2:19
a4,a6,d1:29
a4,a6,d2:30
a4,d1,d2:19
a5,a6,d1:29
a5,d1,d2:19
candidate set:
a1,a2,a3,a4:19
a1,a2,a3,a5:29
a1,a2,a3,d1:19
a1,a2,a3,d2:29
a1,a2,a4,a5:19
a1,a2,a4,d1:19
a1,a2,a4,d2:19
a1,a2,a5,d1:19
a1,a2,a5,d2:29
a1,a2,d1,d2:19
a1,a3,a4,a5:19
a1,a3,a4,a6:30
a1,a3,a4,d1:19
a1,a3,a4,d2:40
a1,a3,a5,d1:19
a1,a3,a5,d2:29
a1,a3,a6,d2:30
a1,a3,d1,d2:19
a1,a4,a5,a6:12
a1,a4,a5,d1:28
a1,a4,a5,d2:19
a1,a4,a6,d1:12
a1,a4,a6,d2:30
a1,a4,d1,d2:19
a1,a5,a6,d1:12
a1,a5,d1,d2:19
a2,a3,a4,a5:19
a2,a3,a4,d1:19
a2,a3,a4,d2:19
a2,a3,a5,d1:19
a2,a3,a5,d2:29
a2,a3,d1,d2:19
a2,a4,a5,d1:19
a2,a4,a5,d2:19
a2,a4,d1,d2:19
a2,a5,d1,d2:19
a3,a4,a5,d1:19
a3,a4,a5,d2:19
a3,a4,a6,d2:30
a3,a4,d1,d2:19
a3,a5,d1,d2:19
a4,a5,a6,d1:29
a4,a5,d1,d2:19
after pruning:
a1,a2,a3,a4:19
a1,a2,a3,a5:29
a1,a2,a3,d1:19
a1,a2,a3,d2:29
a1,a2,a4,a5:19
a1,a2,a4,d1:19
a1,a2,a4,d2:19
a1,a2,a5,d1:19
a1,a2,a5,d2:29
a1,a2,d1,d2:19
a1,a3,a4,a5:19
a1,a3,a4,a6:30
a1,a3,a4,d1:19
a1,a3,a4,d2:40
a1,a3,a5,d1:19
a1,a3,a5,d2:29
a1,a3,a6,d2:30
a1,a3,d1,d2:19
a1,a4,a5,a6:12
a1,a4,a5,d1:28
a1,a4,a5,d2:19
a1,a4,a6,d1:12
a1,a4,a6,d2:30
a1,a4,d1,d2:19
a1,a5,a6,d1:12
a1,a5,d1,d2:19
a2,a3,a4,a5:19
a2,a3,a4,d1:19
a2,a3,a4,d2:19
a2,a3,a5,d1:19
a2,a3,a5,d2:29
a2,a3,d1,d2:19
a2,a4,a5,d1:19
a2,a4,a5,d2:19
a2,a4,d1,d2:19
a2,a5,d1,d2:19
a3,a4,a5,d1:19
a3,a4,a5,d2:19
a3,a4,a6,d2:30
a3,a4,d1,d2:19
a3,a5,d1,d2:19
a4,a5,a6,d1:29
a4,a5,d1,d2:19
candidate set:
a1,a2,a3,a4,a5:19
a1,a2,a3,a4,d1:19
a1,a2,a3,a4,d2:19
a1,a2,a3,a5,d1:19
a1,a2,a3,a5,d2:29
a1,a2,a3,d1,d2:19
a1,a2,a4,a5,d1:19
a1,a2,a4,a5,d2:19
a1,a2,a4,d1,d2:19
a1,a2,a5,d1,d2:19
a1,a3,a4,a5,d1:19
a1,a3,a4,a5,d2:19
a1,a3,a4,a6,d2:30
a1,a3,a4,d1,d2:19
a1,a3,a5,d1,d2:19
a1,a4,a5,a6,d1:12
a1,a4,a5,d1,d2:19
a2,a3,a4,a5,d1:19
a2,a3,a4,a5,d2:19
a2,a3,a4,d1,d2:19
a2,a3,a5,d1,d2:19
a2,a4,a5,d1,d2:19
a3,a4,a5,d1,d2:19
after pruning:
a1,a2,a3,a4,a5:19
a1,a2,a3,a4,d1:19
a1,a2,a3,a4,d2:19
a1,a2,a3,a5,d1:19
a1,a2,a3,a5,d2:29
a1,a2,a3,d1,d2:19
a1,a2,a4,a5,d1:19
a1,a2,a4,a5,d2:19
a1,a2,a4,d1,d2:19
a1,a2,a5,d1,d2:19
a1,a3,a4,a5,d1:19
a1,a3,a4,a5,d2:19
a1,a3,a4,a6,d2:30
a1,a3,a4,d1,d2:19
a1,a3,a5,d1,d2:19
a1,a4,a5,a6,d1:12
a1,a4,a5,d1,d2:19
a2,a3,a4,a5,d1:19
a2,a3,a4,a5,d2:19
a2,a3,a4,d1,d2:19
a2,a3,a5,d1,d2:19
a2,a4,a5,d1,d2:19
a3,a4,a5,d1,d2:19
candidate set:
a1,a2,a3,a4,a5,d1:19
a1,a2,a3,a4,a5,d2:19
a1,a2,a3,a4,d1,d2:19
a1,a2,a3,a5,d1,d2:19
a1,a2,a4,a5,d1,d2:19
a1,a3,a4,a5,d1,d2:19
a2,a3,a4,a5,d1,d2:19
after pruning:
a1,a2,a3,a4,a5,d1:19
a1,a2,a3,a4,a5,d2:19
a1,a2,a3,a4,d1,d2:19
a1,a2,a3,a5,d1,d2:19
a1,a2,a4,a5,d1,d2:19
a1,a3,a4,a5,d1,d2:19
a2,a3,a4,a5,d1,d2:19
candidate set:
a1,a2,a3,a4,a5,d1,d2:19
after pruning:
a1,a2,a3,a4,a5,d1,d2:19
candidate set:
after pruning:
The final frequency set is:
['a1,a2,a3,a4,a5,d1,d2']
The rule is:
a1->a3^a2^a5^a4^d2^d1 0.253333333333
a2->a1^a3^a5^a4^d2^d1 0.655172413793
a3->a1^a2^a5^a4^d2^d1 0.271428571429
a4->a1^a3^a2^a5^d2^d1 0.2375
a5->a1^a3^a2^a4^d2^d1 0.322033898305
d1->a1^a3^a2^a5^a4^d2 0.322033898305
d2->a1^a3^a2^a5^a4^d1 0.38
a1^a2->a3^a5^a4^d2^d1 0.655172413793
a1^a3->a2^a5^a4^d2^d1 0.358490566038
a1^a4->a3^a2^a5^d2^d1 0.365384615385
a1^a5->a3^a2^a4^d2^d1 0.5
a1^d1->a3^a2^a5^a4^d2 0.612903225806
a1^d2->a3^a2^a5^a4^d1 0.38
a2^a3->a1^a5^a4^d2^d1 0.655172413793
a2^a4->a1^a3^a5^d2^d1 1.0
a2^a5->a1^a3^a4^d2^d1 0.655172413793
a2^d1->a1^a3^a5^a4^d2 1.0
a2^d2->a1^a3^a5^a4^d1 0.655172413793
a3^a4->a1^a2^a5^d2^d1 0.475
a3^a5->a1^a2^a4^d2^d1 0.655172413793
a3^d1->a1^a2^a5^a4^d2 1.0
a3^d2->a1^a2^a5^a4^d1 0.38
a4^a5->a1^a3^a2^d2^d1 0.387755102041
a4^d1->a1^a3^a2^a5^d2 0.322033898305
a4^d2->a1^a3^a2^a5^d1 0.475
a5^d1->a1^a3^a2^a4^d2 0.387755102041
a5^d2->a1^a3^a2^a4^d1 0.655172413793
d1^d2->a1^a3^a2^a5^a4 1.0
a1^a2^a3->a5^a4^d2^d1 0.655172413793
a1^a2^a4->a3^a5^d2^d1 1.0
a1^a2^a5->a3^a4^d2^d1 0.655172413793
a1^a2^d1->a3^a5^a4^d2 1.0
a1^a2^d2->a3^a5^a4^d1 0.655172413793
a1^a3^a4->a2^a5^d2^d1 0.475
a1^a3^a5->a2^a4^d2^d1 0.655172413793
a1^a3^d1->a2^a5^a4^d2 1.0
a1^a3^d2->a2^a5^a4^d1 0.38
a1^a4^a5->a3^a2^d2^d1 0.678571428571
a1^a4^d1->a3^a2^a5^d2 0.612903225806
a1^a4^d2->a3^a2^a5^d1 0.475
a1^a5^d1->a3^a2^a4^d2 0.678571428571
a1^a5^d2->a3^a2^a4^d1 0.655172413793
a1^d1^d2->a3^a2^a5^a4 1.0
a2^a3^a4->a1^a5^d2^d1 1.0
a2^a3^a5->a1^a4^d2^d1 0.655172413793
a2^a3^d1->a1^a5^a4^d2 1.0
a2^a3^d2->a1^a5^a4^d1 0.655172413793
a2^a4^a5->a1^a3^d2^d1 1.0
a2^a4^d1->a1^a3^a5^d2 1.0
a2^a4^d2->a1^a3^a5^d1 1.0
a2^a5^d1->a1^a3^a4^d2 1.0
a2^a5^d2->a1^a3^a4^d1 0.655172413793
a2^d1^d2->a1^a3^a5^a4 1.0
a3^a4^a5->a1^a2^d2^d1 1.0
a3^a4^d1->a1^a2^a5^d2 1.0
a3^a4^d2->a1^a2^a5^d1 0.475
a3^a5^d1->a1^a2^a4^d2 1.0
a3^a5^d2->a1^a2^a4^d1 0.655172413793
a3^d1^d2->a1^a2^a5^a4 1.0
a4^a5^d1->a1^a3^a2^d2 0.387755102041
a4^a5^d2->a1^a3^a2^d1 1.0
a4^d1^d2->a1^a3^a2^a5 1.0
a5^d1^d2->a1^a3^a2^a4 1.0
a1^a2^a3^a4->a5^d2^d1 1.0
a1^a2^a3^a5->a4^d2^d1 0.655172413793
a1^a2^a3^d1->a5^a4^d2 1.0
a1^a2^a3^d2->a5^a4^d1 0.655172413793
a1^a2^a4^a5->a3^d2^d1 1.0
a1^a2^a4^d1->a3^a5^d2 1.0
a1^a2^a4^d2->a3^a5^d1 1.0
a1^a2^a5^d1->a3^a4^d2 1.0
a1^a2^a5^d2->a3^a4^d1 0.655172413793
a1^a2^d1^d2->a3^a5^a4 1.0
a1^a3^a4^a5->a2^d2^d1 1.0
a1^a3^a4^d1->a2^a5^d2 1.0
a1^a3^a4^d2->a2^a5^d1 0.475
a1^a3^a5^d1->a2^a4^d2 1.0
a1^a3^a5^d2->a2^a4^d1 0.655172413793
a1^a3^d1^d2->a2^a5^a4 1.0
a1^a4^a5^d1->a3^a2^d2 0.678571428571
a1^a4^a5^d2->a3^a2^d1 1.0
a1^a4^d1^d2->a3^a2^a5 1.0
a1^a5^d1^d2->a3^a2^a4 1.0
a2^a3^a4^a5->a1^d2^d1 1.0
a2^a3^a4^d1->a1^a5^d2 1.0
a2^a3^a4^d2->a1^a5^d1 1.0
a2^a3^a5^d1->a1^a4^d2 1.0
a2^a3^a5^d2->a1^a4^d1 0.655172413793
a2^a3^d1^d2->a1^a5^a4 1.0
a2^a4^a5^d1->a1^a3^d2 1.0
a2^a4^a5^d2->a1^a3^d1 1.0
a2^a4^d1^d2->a1^a3^a5 1.0
a2^a5^d1^d2->a1^a3^a4 1.0
a3^a4^a5^d1->a1^a2^d2 1.0
a3^a4^a5^d2->a1^a2^d1 1.0
a3^a4^d1^d2->a1^a2^a5 1.0
a3^a5^d1^d2->a1^a2^a4 1.0
a4^a5^d1^d2->a1^a3^a2 1.0
a1^a2^a3^a4^a5->d2^d1 1.0
a1^a2^a3^a4^d1->a5^d2 1.0
a1^a2^a3^a4^d2->a5^d1 1.0
a1^a2^a3^a5^d1->a4^d2 1.0
a1^a2^a3^a5^d2->a4^d1 0.655172413793
a1^a2^a3^d1^d2->a5^a4 1.0
a1^a2^a4^a5^d1->a3^d2 1.0
a1^a2^a4^a5^d2->a3^d1 1.0
a1^a2^a4^d1^d2->a3^a5 1.0
a1^a2^a5^d1^d2->a3^a4 1.0
a1^a3^a4^a5^d1->a2^d2 1.0
a1^a3^a4^a5^d2->a2^d1 1.0
a1^a3^a4^d1^d2->a2^a5 1.0
a1^a3^a5^d1^d2->a2^a4 1.0
a1^a4^a5^d1^d2->a3^a2 1.0
a2^a3^a4^a5^d1->a1^d2 1.0
a2^a3^a4^a5^d2->a1^d1 1.0
a2^a3^a4^d1^d2->a1^a5 1.0
a2^a3^a5^d1^d2->a1^a4 1.0
a2^a4^a5^d1^d2->a1^a3 1.0
a3^a4^a5^d1^d2->a1^a2 1.0
a1^a2^a3^a4^a5^d1->d2 1.0
a1^a2^a3^a4^a5^d2->d1 1.0
a1^a2^a3^a4^d1^d2->a5 1.0
a1^a2^a3^a5^d1^d2->a4 1.0
a1^a2^a4^a5^d1^d2->a3 1.0
a1^a3^a4^a5^d1^d2->a2 1.0
a2^a3^a4^a5^d1^d2->a1 1.0
The associative rule is:
('a2^a4->a1^a3^a5^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^d1->a1^a3^a5^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a3^d1->a1^a2^a5^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('d1^d2->a1^a3^a2^a5^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^a4->a3^a5^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^d1->a3^a5^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a3^d1->a2^a5^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^d1^d2->a3^a2^a5^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^a3^a4->a1^a5^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^a3^d1->a1^a5^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^a4^a5->a1^a3^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^a4^d1->a1^a3^a5^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a2^a4^d2->a1^a3^a5^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^a5^d1->a1^a3^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 3.0)
('a2^d1^d2->a1^a3^a5^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a3^a4^a5->a1^a2^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a3^a4^d1->a1^a2^a5^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a3^a5^d1->a1^a2^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a3^d1^d2->a1^a2^a5^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a4^a5^d2->a1^a3^a2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a4^d1^d2->a1^a3^a2^a5', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a5^d1^d2->a1^a3^a2^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^a3^a4->a5^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^a3^d1->a5^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^a4^a5->a3^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^a4^d1->a3^a5^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a2^a4^d2->a3^a5^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^a5^d1->a3^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 3.0)
('a1^a2^d1^d2->a3^a5^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a3^a4^a5->a2^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a3^a4^d1->a2^a5^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a3^a5^d1->a2^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a3^d1^d2->a2^a5^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a4^a5^d2->a3^a2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a4^d1^d2->a3^a2^a5', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a5^d1^d2->a3^a2^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^a3^a4^a5->a1^d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^a3^a4^d1->a1^a5^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a2^a3^a4^d2->a1^a5^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.285714285714286)
('a2^a3^a5^d1->a1^a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 3.0)
('a2^a3^d1^d2->a1^a5^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.285714285714286)
('a2^a4^a5^d1->a1^a3^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.4)
('a2^a4^a5^d2->a1^a3^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a2^a4^d1^d2->a1^a3^a5', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a2^a5^d1^d2->a1^a3^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 3.0)
('a3^a4^a5^d1->a1^a2^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a3^a4^a5^d2->a1^a2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a3^a4^d1^d2->a1^a2^a5', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a3^a5^d1^d2->a1^a2^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a4^a5^d1^d2->a1^a3^a2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a2^a3^a4^a5->d2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^a3^a4^d1->a5^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a2^a3^a4^d2->a5^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.4489795918367347)
('a1^a2^a3^a5^d1->a4^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 3.0)
('a1^a2^a3^d1^d2->a5^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.4489795918367347)
('a1^a2^a4^a5^d1->a3^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.4)
('a1^a2^a4^a5^d2->a3^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a2^a4^d1^d2->a3^a5', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a2^a5^d1^d2->a3^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 3.0)
('a1^a3^a4^a5^d1->a2^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a3^a4^a5^d2->a2^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a3^a4^d1^d2->a2^a5', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a3^a5^d1^d2->a2^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 6.315789473684211)
('a1^a4^a5^d1^d2->a3^a2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a2^a3^a4^a5^d1->a1^d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.4)
('a2^a3^a4^a5^d2->a1^d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 3.870967741935484)
('a2^a3^a4^d1^d2->a1^a5', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 3.1578947368421053)
('a2^a3^a5^d1^d2->a1^a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.3076923076923075)
('a2^a4^a5^d1^d2->a1^a3', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.2641509433962264)
('a3^a4^a5^d1^d2->a1^a2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a1^a2^a3^a4^a5^d1->d2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.4)
('a1^a2^a3^a4^a5^d2->d1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.0338983050847457)
('a1^a2^a3^a4^d1^d2->a5', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 2.0338983050847457)
('a1^a2^a3^a5^d1^d2->a4', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 1.5)
('a1^a2^a4^a5^d1^d2->a3', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 1.7142857142857142)
('a1^a3^a4^a5^d1^d2->a2', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 4.137931034482759)
('a2^a3^a4^a5^d1^d2->a1', ':', 'support->', 0.15833333333333333, 'coffidence->', 1.0, 'lift->', 1.6)
